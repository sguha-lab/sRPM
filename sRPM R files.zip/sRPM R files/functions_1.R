

fn.fixedClust <- function(All.Stuff)
{
  fixedClust = NULL
  
  fixedClust$c.v = All.Stuff$estClust$c.v
  fixedClust$G = All.Stuff$estClust$G
  fixedClust$phi.mt = All.Stuff$estClust$phi.mt
  fixedClust$v.v  = All.Stuff$estClust$v.v 
  
  fixedClust$C.m.vec <- array(,fixedClust$G)
  
  for (g in 1:fixedClust$G)
  {I.g <- (fixedClust$c.v==g)
  fixedClust$C.m.vec[g] <- sum(I.g)
  }
  
  fixedClust
}


fn.MLEClusters <- function(All.Stuff, fixedClust, full.data.in)
{
  parm = NULL
  parm$col.subset.I <- 1:full.data.in$p
  parm$X = full.data.in$X
  parm$Y.v = full.data.in$Y.v
  parm$d = full.data.in$d
  
  parm$clust$C.m.vec <- fixedClust$C.m.vec
  parm$clust$G = fixedClust$G
  parm$clust$phi.mt = All.Stuff$phi.mt 
  parm$clust$v.v = All.Stuff$v.v 
  parm$clust$invSigma.ar = All.Stuff$invSigma.ar 
  parm$clust$Sigma.ar = array(apply(parm$clust$invSigma.ar,3,solve), c(2,2,parm$clust$G ))
  parm$sigma = mean(All.Stuff$sigma.v)
  
  parm$clust$logDet.v = array(,parm$clust$G)
  for (tt in 1:parm$clust$G)
    {parm$clust$logDet.v[tt] = determinant(parm$clust$Sigma.ar[,,tt], log=TRUE)$mod
    }
  
  parm$clust$offset.v = All.Stuff$parm$clust$offset.v
  parm$p_t.v = All.Stuff$parm$p_t.v
  
  parm = sRPM_fn.M(parm, useYFlag=FALSE)
  
  parm$clust$c.v = apply(parm$clust$col_subset_post.prob.mt,2,which.max)
  parm$pred.v = parm$clust$v.v[parm$clust$c.v]
    
  
  resid.v = full.data.in$Y.v-parm$pred.v
  parm$trainRSq = 1-mean(resid.v^2)/All.Stuff$parm$var.Y
  
  
  parm = sRPM_fn.M(parm, useYFlag=FALSE)
  parm$clust$p.v = as.vector(parm$clust$C.m.vec/full.data.in$p)
  
  parm$justLikPrior = sum(colSums(parm$justLik * parm$clust$p.v))

  
  parm
  
}




fn.secondImageClusters <- function(parm, data.in)
{
 
  parm$col.subset.I <- 1:data.in$p
  parm$clust$K = parm$d
  parm$sigma = parm$hatSigma = mean(parm$init.All.Stuff$sigma.v)
  
  parm$clust$G = parm$fixedClust$G
  parm$clust$offset.v = c(parm$clust$offset.v, rep(0,parm$fixedClust$G))
  parm = fn.niwPrior(parm)
  
  parm$clust$c.v = parm$fixedClust$c.v
  parm$clust$C.m.vec <- c(parm$fixedClust$C.m.vec, rep(0,parm$fixedClust$G))
  
  parm = fn.ClustList(parm)
  
  parm$clust$v.v = c(parm$fixedClust$v.v, rep(NA,parm$fixedClust$G))
  parm$clust$mu2 = mean(parm$clust$v.v, na.rm = TRUE)
  parm$clust$tau2 = sd(parm$clust$v.v, na.rm = TRUE)
  parm = fn.FasterSummary.clust(parm)
  parm = fn.niwPosterior(parm)
  
  parm = fn.genMuSigmaV(parm)
  
  parm = sRPM_fn.M(parm, useYFlag=TRUE)
  
  parm$clust$c.v = apply(parm$clust$col_subset_post.prob.mt,2,which.max)
  
  parm
  
}



fn.FasterSummary.clust <- function(parm)
{
  
  parm$S = array(,c(parm$clust$K,parm$clust$K,parm$clust$G))
  parm$xBar = array(,c(parm$clust$K,parm$clust$G))
  parm$yBar = array(,parm$clust$G)
  
  flag.single = parm$clust$C.m.vec==1
  flag.empty = parm$clust$C.m.vec==0
  
  null.flag = (is.null(parm$niw$prior$mu0.v[,1]))
  
  for (gg in (1:parm$clust$G)[flag.empty]) 
  {
    parm$S[,,gg] = 0
   
    if (!null.flag)
      {parm$xBar[,gg] = parm$niw$prior$mu0.v[,gg]
      }
    if (null.flag)
      {parm$xBar[,gg] = 0
    }
    parm$yBar[gg] = parm$clust$mu2
    
  }
  
  for (gg in (1:parm$clust$G)[flag.single]) 
  {
  indx.gg=parm$clust$list[[gg]] 
  
  parm$S[,,gg] = 0
  parm$xBar[,gg] = parm$X[,indx.gg]
  parm$yBar[gg] = parm$Y.v[indx.gg]
  
  }
  
  for (gg in (1:parm$clust$G)[!flag.single & !flag.empty]) 
  {
    indx.gg=parm$clust$list[[gg]] 
    
    parm$S[,,gg] = (parm$clust$C.m.vec[gg]-1)*var(t(parm$X[,indx.gg]))
   
    parm$xBar[,gg] = rowMeans(parm$X[,indx.gg]) 
    parm$yBar[gg] = mean(parm$Y.v[indx.gg])
  }
  
  parm
}


fn.ClustList <- function(parm, gg.set=NULL)
{
  
  if (is.null(gg.set)){
    parm$clust$list = rep(list(NA),parm$clust$G)
    gg.set = 1:parm$clust$G
  } 
  
  c.v = parm$clust$c.v
  parm$clust$list[gg.set] = lapply(gg.set, function(gg) {which(c.v==gg)}) 
    
  parm
  
}


fn.getMeanDistances <- function(parm)
{
  distSq.mt = array(0,c(parm$clust$G,parm$clust$G))
  
  for (t in 1:parm$clust$K)
  {distSq.mt = distSq.mt + outer(parm$clust$phi.mt[t,],parm$clust$phi.mt[t,],"-")^2
  }
  
  parm$meanDist = mean(sqrt(distSq.mt[upper.tri(distSq.mt)]))
  parm$maxDist = max(sqrt(distSq.mt[upper.tri(distSq.mt)]))
  
  parm
}


fn.init.clusters <- function(data.in, parm)
{

	parm$XY.mt <- rbind(data.in$X, data.in$Y.v)
	
	if (parm$updateClusterAlloc)
	  {num.centers <- parm$G.max
	
	  options(warn=0)
	  tmp2 <- kmeans(t(parm$XY.mt), iter.max=1000, centers=num.centers, nstart=2, algorithm = "Lloyd")
	  options(warn=2)
	  #
	  parm$clust$c.v <- tmp2$cluster  
	  parm$clust$G <- length(tmp2$size)
	  
	  parm$clust$phi.mt = t(tmp2$centers[,1:data.in$d])
	  
	  parm$clust$v.v = as.vector(tmp2$centers[,-(1:data.in$d)])
	  
	  meanPhi.v = apply(parm$clust$phi.mt,1,mean,na.rm=TRUE)
	  meanV.v = mean(parm$clust$v.v,na.rm=TRUE)
	  emptyClust = which(parm$clust$C.m.vec==0)
	  if (length(emptyClust)>0)
	  {for (z in 1:parm$d)
  	    {parm$clust$phi.mt[z,emptyClust] = meanPhi.v[z]
  	    }
  	  parm$clust$v.v[emptyClust] = meanV.v
  	  }
	  }
	
	if (!parm$updateClusterAlloc)
	  {
	  parm$clust$c.v <- parm$fixedClust$c.v
	  parm$clust$G <- parm$fixedClust$G
	  parm$clust$phi.mt = parm$fixedClust$phi.mt
	  parm$clust$v.v  = parm$fixedClust$v.v
	  }
	
	parm
}


fn.eda <- function(data.in, parm)
{
 
  parm$clust$C.m.vec <- array(,parm$clust$G)
  
  for (g in 1:parm$clust$G)
    {I.g <- (parm$clust$c.v==g)
    parm$clust$C.m.vec[g] <- sum(I.g)
    }
  
  parm = fn.ClustList(parm)
  
  if ( (!parm$useLastImage) | (parm$useLastImage & !parm$updateClusterAlloc) )
    {
    
    parm$clust$K = parm$d
    
    parm = fn.getMeanDistances(parm)
    
    parm$clust$mu2 = mean(parm$clust$v.v, na.rm = TRUE)
    parm$clust$tau2 = sd(parm$clust$v.v, na.rm = TRUE)
  	
  	parm = fn.FasterSummary.clust(parm)
    
    parm$sigma = parm$hatSigma = sqrt(var(data.in$Y.v)*(1-parm$targetRSq))
    
    parm = fn.niwPrior(parm)
    parm = fn.genMuSigmaV(parm)
    
    } 
    
	parm = fn.assign.priors(data.in, parm)
  parm = fn.hyperparameters(data.in, parm)
	parm$clust$C.m0 <- parm$p - sum(parm$clust$C.m.vec)

	parm$clust$M <- parm$a.R
	parm$clust$M0 <- 0
	parm$N <- parm$d
	
	parm$g <- rep(1:parm$clust$G,each=parm$d)

  parm

	}



fn.init <- function(data.in, targetRSq, scaleTheta.in, updateClusterAlloc, fixedClust, useLastImage, init.All.Stuff)
	{

	parm <- NULL

	parm$d <- data.in$d
	parm$p <- data.in$p
	parm$r = data.in$r
	parm$p_t.v <- data.in$p_t.v
	
	parm$var.Y = var(data.in$Y.v)
	parm$maxRSq = -Inf

	parm$targetRSq = targetRSq

	parm$X <- data.in$X
	parm$Y.v = data.in$Y.v
	
	parm$G.max <- data.in$G.max
	
	# initially
	parm$updateTheta = updateClusterAlloc
	parm$scaleTheta = scaleTheta.in
	
	parm$updateClusterAlloc = updateClusterAlloc
	parm$fixedClust = fixedClust
	
	parm$useLastImage = useLastImage
	parm$init.All.Stuff = init.All.Stuff

	# for second image
	if (parm$useLastImage)
    {parm$clust$offset.v = parm$init.All.Stuff$parm$clust$C.m.vec
    }
	
	if ( (!parm$useLastImage) | (parm$useLastImage & !parm$updateClusterAlloc) )
  	{parm <- fn.init.clusters(data.in, parm)
	  }
	
	if (parm$useLastImage & parm$updateClusterAlloc)
  	{parm <- fn.secondImageClusters(parm, data.in)
  	}

	if (!parm$useLastImage)
	  {parm$clust$offset.v = rep(0,parm$clust$G)
  	}
	
	parm <- fn.eda(data.in, parm)

	if (parm$updateClusterAlloc)
	{ tmp.parm = parm
	  c.v = parm$clust$c.v
	  
	  tmp.parm$clust$c.v = c.v
	}
	
		parm

	}



fn.assign.priors <- function(data.in, parm)
	{
  
  parm$prior <- NULL
  
  parm$prior$scaleTheta <- NULL
  parm$prior$scaleTheta$shape= 1
  parm$prior$scaleTheta$rate= 1
  parm$prior$scaleTheta$min = 1e-5
 
  
  parm$prior$K0 <- NULL
  parm$prior$K0$shape= 1
  parm$prior$K0$rate= 1

	parm$prior$sigma <- NULL
	parm$prior$sigma$shape <- .1*parm$hatSigma
	parm$prior$sigma$rate <- .1
	parm$prior$sigma$max <- sqrt(var(data.in$Y.v)*(1-parm$targetRSq))
	maxxRSq = .99
	parm$prior$sigma$min <- sqrt(var(data.in$Y.v)*(1-maxxRSq))
	 
	
	parm
	}


fn.trace <- function(M)
{sum(diag(M))}

fn.logMultGamma <- function(a, p)
{
  p*(p-1)/4*log(pi) + sum(lgamma(a + (1-(1:p))/2))
  
}


fn.niwPrior <- function(parm)
{
    parm$niw = NULL
    parm$niw$prior = NULL
    parm$niw$prior$mu0.v = array(0,c(parm$d,parm$clust$G)) 
    parm$niw$prior$K0 = array(parm$scaleTheta,parm$clust$G) 
    parm$niw$prior$Sigma0 = array(,c(parm$d,parm$d,parm$clust$G))
    parm$niw$prior$v0 = array((parm$d + 4) ,parm$clust$G)
    
    for (gg in 1:parm$clust$G)
      {parm$niw$prior$Sigma0[,,gg] = parm$scaleTheta * diag(parm$d)
      }
    
    const1 = as.numeric(determinant(parm$niw$prior$Sigma0[,,1], log=TRUE)$mod)
    const2 = -fn.logMultGamma(a=parm$niw$prior$v0[1]/2, p=parm$d) + parm$niw$prior$v0[1]/2*const1 + parm$d/2*log(parm$niw$prior$K0[1])
    parm$niw$prior$logDet.v = array(const1, parm$clust$G)
    parm$niw$logSimilarPrior.v = array(const2, parm$clust$G)
 
  if (parm$useLastImage)
  {parm$niw2 = NULL
   parm$niw2$prior = parm$init.All.Stuff$parm$niw$post
   parm$niw2$logSimilarPrior.v = c(parm$init.All.Stuff$parm$clust$logSimilar.v, rep(NA,parm$clust$G))
   
   parm$niw$prior$mu0.v = cbind(parm$niw2$prior$mu0.v, parm$niw$prior$mu0.v)
   parm$niw$prior$K0 = c(parm$niw2$prior$K0, parm$niw$prior$K0)
   parm$niw$prior$Sigma0 = abind(parm$niw2$prior$Sigma0, parm$niw$prior$Sigma0)
   parm$niw$prior$v0 = c(parm$niw2$prior$v0, parm$niw$prior$v0)
   
   parm$clust$G = length(parm$niw$prior$v0)
  }
  
  parm
}


fn.niwPosterior <- function(parm)
{
  
  parm$niw$post = NULL
  
  parm$niw$post$mu0.v = array(,c(parm$d,parm$clust$G))
  parm$niw$post$Sigma0 = array(,c(parm$d,parm$d,parm$clust$G))
  parm$niw$post$K0 = parm$niw$post$v0 = parm$niw$post$logDet.v = array(,parm$clust$G)
  
  parm$clust$logSimilar.v = parm$niw$logSimilarPrior.v 
  
  for (gg in 1:parm$clust$G)
    {h_gg = parm$clust$C.m.vec[gg] 
    parm$niw$post$mu0.v[,gg] = parm$niw$prior$K0[gg]/(parm$niw$prior$K0[gg] + h_gg)*parm$niw$prior$mu0.v[,gg] + h_gg/(parm$niw$prior$K0[gg] + h_gg)*parm$xBar[,gg]
    parm$niw$post$K0[gg] = parm$niw$prior$K0[gg] + h_gg
    parm$niw$post$v0[gg] = parm$niw$prior$v0[gg] + h_gg
    parm$niw$post$Sigma0[,,gg] = parm$niw$prior$Sigma0[,,gg] + parm$S[,,gg] + h_gg*parm$niw$prior$K0[gg]/(parm$niw$prior$K0[gg] + h_gg)*(parm$xBar[,gg]-parm$niw$prior$mu0.v[,gg])%*%t(parm$xBar[,gg]-parm$niw$prior$mu0.v[,gg])
    parm$niw$post$logDet.v[gg] = as.numeric(determinant(parm$niw$post$Sigma0[,,gg], log=TRUE)$mod)
    
    parm$clust$logSimilar.v[gg] = parm$clust$logSimilar.v[gg] -parm$clust$C.m.vec[gg]*parm$d/2*log(pi) + fn.logMultGamma(a=parm$niw$post$v0[gg]/2, p=parm$d) 
    parm$clust$logSimilar.v[gg] = parm$clust$logSimilar.v[gg] - parm$niw$post$v0[gg]/2*parm$niw$post$logDet[gg]
    parm$clust$logSimilar.v[gg] = parm$clust$logSimilar.v[gg] - parm$d/2*log(parm$niw$post$K0[gg])
    }
  
  parm
}



fn.genMuSigmaV <- function(parm)
{ 
  parm = fn.niwPosterior(parm)
    
  parm$clust$Sigma.ar = parm$clust$invSigma.ar = array(,c(parm$clust$K,parm$clust$K,parm$clust$G))
  parm$clust$phi.mt = array(,c(parm$clust$K,parm$clust$G))
  parm$clust$chiSq.v = parm$clust$logDet.v = array(,parm$clust$G)
  

  for (gg in 1:parm$clust$G)
    {
    
    tmp.lst = rniw(n=1, lambda=parm$niw$post$mu0.v[,gg], kappa=parm$niw$post$K0[gg], Psi=parm$niw$post$Sigma0[,,gg], nu=parm$niw$post$v0[gg])
    parm$clust$Sigma.ar[,,gg] = tmp.lst$Sigma
    invSigma_gg.mt = solve(parm$clust$Sigma.ar[,,gg])
    parm$clust$phi.mt[,gg] =  tmp.lst$mu
      
    parm$clust$invSigma.ar[,,gg] = invSigma_gg.mt
    parm$clust$logDet.v[gg] = as.numeric(determinant(parm$clust$Sigma.ar[,,gg], log=TRUE)$mod)
    parm$clust$chiSq.v[gg] = t(parm$clust$phi.mt[,gg]-parm$niw$post$mu0.v[,gg]) %*% parm$clust$invSigma.ar[,,gg] %*% (parm$clust$phi.mt[,gg]-parm$niw$post$mu0.v[,gg])
    
  } # end   for 
  
  var.v = 1/(1/parm$clust$tau2^2 + parm$clust$C.m.vec/parm$sigma^2)
  sd.v = sqrt(var.v)
  mu.v = var.v * (parm$clust$mu2/parm$clust$tau2^2 + parm$clust$C.m.vec/parm$sigma^2*parm$yBar)
  parm$clust$v.v = rnorm(n=parm$clust$G, mean=mu.v, sd= sd.v)
  
  parm
  
}



fn.hyperparameters <- function(data.in, parm)
{ 
  if (parm$updateTheta)
  {
    sumInvSigma = apply(parm$clust$invSigma.ar,1:2,sum)
    traceSumInvSigma = fn.trace(sumInvSigma) 
  
    
    shape= data.in$d*parm$clust$G*parm$niw$prior$v0[1]/2 + parm$prior$scaleTheta$shape
    rate= traceSumInvSigma/2 + parm$prior$scaleTheta$rate
    # shape/rate
    u.min = pgamma(parm$prior$scaleTheta$min, shape=shape, scale=1/rate)
    flag = u.min < (1-1e-5)
    if (flag)
    {u = runif(n=1,min=u.min)
    parm$scaleTheta = qgamma(u, shape=shape, scale=1/rate)
    }
    if (!flag)
    {parm$scaleTheta =  parm$prior$scaleTheta$min
    }
  
  
    if ( (!parm$useLastImage) | (parm$useLastImage & !parm$updateClusterAlloc) )
      {parm = fn.niwPrior(parm)
      }
  } # end if 
  
  
    resid.v = data.in$Y.v-parm$clust$v.v[parm$clust$c.v]
    sum.resid.sq <- sum(resid.v^2)
    
    shape <- parm$prior$sigma$shape + data.in$p/2
    rate <- parm$prior$sigma$rate + sum.resid.sq/2
    
    u.min = pgamma(1/parm$prior$sigma$max^2, shape=shape, scale=1/rate)
    u.max = pgamma(1/parm$prior$sigma$min^2, shape=shape, scale=1/rate)
    flag = u.min < (1-1e-5)
    if (flag)
    {u = runif(n=1,min=u.min,max=u.max)
    parm$sigma = 1/sqrt(qgamma(u, shape=shape, scale=1/rate))
    }
    if (!flag)
    {parm$sigma = parm$prior$sigma$max
    }
  
  
  parm
  
}


fn.estCV <- function(parm, data.in)
{

  resid.v = data.in$Y.v-parm$clust$v.v[parm$clust$c.v]
  parm$estRSq = 1-mean(resid.v^2)/parm$var.Y
  
  if (parm$estRSq > parm$maxRSq)
  { parm$maxRSq = parm$estRSq
    parm$clust$est.c.v = parm$clust$c.v 
    parm$clust$est.v.v = parm$clust$v.v 
    parm$clust$est.G = parm$clust$G
    parm$clust$est.C.m.vec = parm$clust$C.m.vec
    parm$clust$est.occupiedG = sum(parm$clust$C.m.vec>0)
    parm$clust$est.phi.mt = parm$clust$phi.mt
  }
  
  parm
  
}


fn.psi <- function(parm, est.parm)
{

  parm$psi = mean(parm$clust$c.v != est.parm$clust$c.v)

  parm  
}


fn.iter <- function(data.in, parm, est.parm=NULL)
	{

	parm = fn.FasterSummary.clust(parm)

	parm = fn.hyperparameters(data.in, parm)
	
	parm = fn.genMuSigmaV(parm)
	
	if (parm$updateClusterAlloc)
	  {parm = fast_sRPM_fn.main(parm, data.in)
	  parm = fn.estCV(parm, data.in)
	  }

	if (parm$useLastImage)
  	{parm = fn.psi(parm, est.parm)
  	}
  	  
	err <- sRPM_fn.compact.consistency.check(parm)
	if (err > 0)
		{stop(paste("failed QC: err=",err))
		}

	parm


	}



fn.mcmc <- function(data.in, n.burn, n.reps, scaleTheta.in, updateClusterAlloc, fixedClust=NULL, useLastImage=FALSE, init.All.Stuff=NULL, num.psi=NULL, est.parm=NULL)
	{
	
	parm <- fn.init(data.in, targetRSq=.55, scaleTheta.in, updateClusterAlloc, fixedClust, useLastImage, init.All.Stuff)
	init.parm <- parm

	err <- sRPM_fn.compact.consistency.check(parm)
	if (err > 0)
	  {stop(paste("failed QC at fn.init: err=",err))
	  }
  
	parm = fn.hyperparameters(data.in, parm)
	parm$updateTheta = FALSE

	tag = NULL
	if (!updateClusterAlloc)
	  {tag = "STABILIZE__"
	  }
	
	text=paste(tag,"BURNIN...")

	for (cc in 1:n.burn)
		{old.parm = parm
	  parm <- fn.iter(data.in, parm)

		if (cc %% 100 == 0)
			{print(paste(text,cc,date(),"***********"))
			}
	  }

	All.Stuff <- NULL
	
	All.Stuff$scaleTheta.v <- All.Stuff$sigma.v <- All.Stuff$G.v <- array(,n.reps)
	All.Stuff$estRSq.v  <- All.Stuff$occupiedG.v <- All.Stuff$logSimilar.v <- array(,n.reps)
	
	if (parm$useLastImage)
  	{All.Stuff$psi.v <- array(,n.reps)
  	}
	  
	if (!updateClusterAlloc)
	{All.Stuff$phi.mt <- array(0,dim(parm$clust$phi.mt))
	All.Stuff$v.v = array(0,length(parm$clust$v.v))
	All.Stuff$Sigma.ar = All.Stuff$invSigma.ar = array(0,dim(parm$clust$Sigma.ar))
	All.Stuff$logDet.v = array(0,length(parm$clust$logDet.v))
	}

	text=paste(tag,"POST--BURNIN...")
	

	for (cc in 1:n.reps)
	  {old.parm = parm
	  parm <- fn.iter(data.in, parm, est.parm)
	  
	  All.Stuff$scaleTheta.v[cc] <- parm$scaleTheta
	  All.Stuff$sigma.v[cc] <- parm$sigma
	  All.Stuff$G.v[cc] <- parm$clust$G
	  All.Stuff$occupiedG.v[cc] <- sum(parm$clust$C.m.vec>0)
	  
	  All.Stuff$logSimilar.v[cc] = sum(parm$clust$logSimilar.v)
	  
	  if (updateClusterAlloc)
	    {All.Stuff$estRSq.v[cc] <- parm$estRSq
	    }
	  
	  if (!updateClusterAlloc)
	    {All.Stuff$phi.mt <- All.Stuff$phi.mt + parm$clust$phi.mt/n.reps
	    All.Stuff$v.v = All.Stuff$v.v + parm$clust$v.v/n.reps
	    All.Stuff$Sigma.ar = All.Stuff$Sigma.ar + parm$clust$Sigma.ar/n.reps
	    All.Stuff$invSigma.ar = All.Stuff$invSigma.ar + parm$clust$invSigma.ar/n.reps
	    All.Stuff$logDet.v = All.Stuff$logDet.v + parm$clust$logDet.v/n.reps
	    }
	  
	  if (parm$useLastImage)
  	  {All.Stuff$psi.v[cc] <- parm$psi
  	  }
	    
	  if (cc %% 100 == 0)
	    {print(paste(text,cc,date(),"***********"))
	    }
	  
	  } # for 
	
	All.Stuff$parm <- parm
	All.Stuff$init.parm <- init.parm
	
	if (updateClusterAlloc)
	  {All.Stuff$estClust = NULL
	  All.Stuff$estClust$v.v = parm$clust$est.v.v
	  All.Stuff$estClust$G = parm$clust$est.G 
	  All.Stuff$estClust$occupiedG = parm$clust$est.occupiedG
	  All.Stuff$estClust$phi.mt = parm$clust$est.phi.mt
	  All.Stuff$estClust$TrainRSq = parm$maxRSq
	  
	  c.v = parm$clust$est.c.v
	  
	  All.Stuff$estClust$c.v = parm$clust$est.c.v = c.v
	  
	  All.Stuff$estClust$C.m.vec <- array(,All.Stuff$estClust$G)
	  
	  for (g in 1:All.Stuff$estClust$G)
	  {I.g <- (All.Stuff$estClust$c.v==g)
	  All.Stuff$estClust$C.m.vec[g] <- sum(I.g)
	  }
	 
	    
	  tmp.parm = All.Stuff$parm
	  tmp.parm$clust = All.Stuff$estClust
	  #
	  }
	
	if (!updateClusterAlloc)
	  {tmp.parm = parm
	  tmp.parm$clust = NULL
	  tmp.parm$clust$G = parm$fixedClust$G
	  tmp.parm$clust$c.v = parm$fixedClust$c.v
	  tmp.parm$clust$v.v = All.Stuff$v.v
	  tmp.parm$clust$phi.mt = All.Stuff$phi.mt
	  }
	  
	if (parm$useLastImage)
  	{
  	  All.Stuff$psiQuantiles = quantile(All.Stuff$psi.v, probs = seq(0,1,len=num.psi))
    	
    	grid=1000
    	psi0.v = seq(0,1,len=grid)
    	sens.v = spec.v = array(,grid)
    	
    	for (ff in 1:grid)
      	{ threshold = psi0.v[ff]
      	
      	
      	correctly_detected = mean(All.Stuff$psiQuantiles > threshold) > .5
      	correctly_not_detected = mean(All.Stuff$psiQuantiles <= threshold) > .5 
      	
      	# if images are truly similar, only spec.v is relevant 
      	spec.v[ff] = correctly_not_detected
      	
      	# if images are truly different, only sens.v is relevant 
      	sens.v[ff] = correctly_detected
      	
      	} # FOR loop
      	
    	All.Stuff$sens.v = sens.v
    	All.Stuff$spec.v = spec.v
    	
  	} # end if 
	
	All.Stuff
	}

