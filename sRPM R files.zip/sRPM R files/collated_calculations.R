
fn.AUC <- function(sens2.v, spec2.v)
{
  grid = length(spec2.v)
  
  v1 = rev(1-spec2.v)
  v2 = rev(sens2.v)
  midpoint.v = (v2[1:(grid-1)] + v2[2:grid])/2
  delta.v =  v1[2:grid]-v1[1:(grid-1)]
  AUC = sum(midpoint.v*delta.v)
  
  AUC
}


grid=1000
psi0.v = seq(0,1,len=grid)
dist.v = array(,grid)

for (ff in 1:grid)
{ threshold = psi0.v[ff]
  
  dist.v[ff] = sqrt((sens2.v[ff]-1)^2 + (1-spec2.v[ff])^2)
    
} # FOR loop

se.sens2.v = apply(sens_tt.mt, 2, sd, na.rm=TRUE)/sqrt(indep.reps)
se.spec2.v = apply(spec_tt.mt, 2, sd, na.rm=TRUE)/sqrt(indep.reps)

pdf("ROC_1.pdf")
plot((1-spec2.v),sens2.v,xlim=c(0,1),ylim=c(0,1),type="l",lwd=2,col="blue",ylab="Sensitivity",xlab="1-Specificity",main="ROC curve",cex=1.2,cex.lab=1.2)
lines((1-spec2.v),sens2.v+1.96*se.sens2.v,lty="dashed",lwd=1,col="blue")
lines((1-spec2.v),sens2.v-1.96*se.sens2.v,lty="dashed",lwd=1,col="blue")
#
legend(0.6, 0.5, legend=c("sRPM"),  fill = c("blue"))
graphics.off()



###########################

AUC = fn.AUC(sens2.v, spec2.v)

hi_AUC = fn.AUC((sens2.v+1.96*se.sens2.v), spec2.v)
lo_AUC = fn.AUC((sens2.v-1.96*se.sens2.v), spec2.v)

# 95% CI
round(c(lo_AUC, hi_AUC), dig=3)


##############################

psi0_opt = psi0.v[which.min(dist.v)]

threshold = psi0_opt
 
########################
  
  confusionMatrix = array(,c(2,2))
  v2 = c("ReallySimilar","ReallyDiff")
  v3 = c("InferSame","InferDiff")
  dimnames(confusionMatrix) = list(v2,v3)
  
  confusionMatrix[1,1] = spec2.v[which.min(dist.v)]
  confusionMatrix[1,2] = 1-confusionMatrix[1,1]
  confusionMatrix[2,2] = sens2.v[which.min(dist.v)]
  confusionMatrix[2,1] = 1-confusionMatrix[2,2]

  # convert to percentages
  # Each column sum is 100%
  confusionMatrix = confusionMatrix*100
  

  se_confusionMatrix = confusionMatrix
  se_confusionMatrix[1,] = se.spec2.v[which.min(dist.v)]
  se_confusionMatrix[2,] = se.sens2.v[which.min(dist.v)]
  
  # convert to percentages
  # Each column sum is 100%
  se_confusionMatrix = round(se_confusionMatrix*100, dig=1)
  
  