


fn3.outerWrapper <- function(x0.mt)
{ 
  r1 = x0.mt[1,]^2
  r2 = x0.mt[1,]*x0.mt[2,]
  r4 = x0.mt[2,]^2
  
  rbind(r1, r2, r2, r4)
}


fnFast.logdmvnorm <- function(gg, x.mt, parm)
{
 
  x0.mt=(x.mt-parm$clust$phi.mt[,gg])
  xx.mt = fn3.outerWrapper(x0.mt)
  
  z.mt = xx.mt * as.vector(parm$clust$invSigma.ar[,,gg])
  
  val.v = -parm$d/2*log(2*pi) -.5*parm$clust$logDet.v[gg] -.5*colSums(z.mt)
  
  val.v
}




sRPM_fn.compact.consistency.check <- function(parm)
{err <- 0

if (max(sort(unique(parm$clust$c.v))) != parm$clust$G)
{err <- 1
}

if (sum(parm$clust$C.m.vec==0) > 0)
{err <- 1.5
}

err <- sRPM_fn.consistency.check(parm)


err
}



sRPM_fn.consistency.check <- function(parm)
{err <- 0


if (sum(parm$clust$C.m.vec) + parm$clust$C.m0 != parm$p)
{err <- 4
}


if (sum(dim(parm$clust$phi.mt) != c(parm$clust$K, parm$clust$G)) > 0)
{err <- 10
}

if (sum(dim(parm$clust$Sigma.ar) != c(parm$clust$K, parm$clust$K, parm$clust$G)) > 0)
{err = 11}

if (sum(dim(parm$clust$invSigma.ar) != c(parm$clust$K, parm$clust$K, parm$clust$G)) > 0)
{err = 11.5}

if (length(parm$clust$list) != parm$clust$G)
{err = 12
}

if (sum(unlist(lapply(parm$clust$list, length)) != parm$clust$C.m.vec) > 0)
{err = 13
}

err
}




sRPM_fn.log.lik <- function(gg, x.mt, y.v, parm, useYFlag=TRUE)
  {

  log.lik.v1 = fnFast.logdmvnorm(gg, x.mt, parm)
  
  log.lik.v2 = 0
  
  if (useYFlag)
    {log.lik.v2 = -.5*log(2*pi)-log(parm$sigma) - .5*(y.v-parm$clust$v.v[gg])^2 / parm$sigma^2
    }
    
  log.lik.v1+log.lik.v2
  }



sRPM_fn.M <- function(parm, useYFlag=TRUE)
{
  
  prior.prob.v <- c(parm$clust$C.m.vec) + c(parm$clust$offset.v)
  
  small <- 1e-3 
  prior.prob.v[prior.prob.v < small] <- small

  subset_log.ss.mt <- array(, c(parm$clust$G, length(parm$col.subset.I)))

  subset_x.mt = matrix(parm$X[,parm$col.subset.I], nrow=parm$d)
  subset_y.v = parm$Y.v[parm$col.subset.I]
  
  subset_log.ss.mt = t(sapply(1:parm$clust$G, sRPM_fn.log.lik, x.mt = subset_x.mt, y.v = subset_y.v, parm, useYFlag))
  parm$justLik =  subset_log.ss.mt 
  
  subset_log.ss.mt <- subset_log.ss.mt + log(prior.prob.v)
  

  maxx.v <- apply(subset_log.ss.mt, 2, max)

  subset_log.ss.mt <- t(t(subset_log.ss.mt) - maxx.v)

    small2 <- log(1e-5)
  subset_log.ss.mt[subset_log.ss.mt < small2] <- small2

  subset_ss.mt <- exp(subset_log.ss.mt)
  col.sums.v <- colSums(subset_ss.mt)
  subset_ss.mt <- t(t(subset_ss.mt)/col.sums.v)

  parm$clust$col_subset_post.prob.mt <- subset_ss.mt
 
  parm$clust$cumSum_col_subset_post.prob.mt = apply(parm$clust$col_subset_post.prob.mt,2,cumsum)

  parm

}

sRPM_fn.post.prob <- function(parm)
  {
    parm$col.subset.I <- sort(sample(1:parm$p, round(.1*parm$p)))
     
    parm = sRPM_fn.M(parm)
    

    old.subset.c <- subset.c <- parm$clust$c.v[parm$col.subset.I]

    parm$clust$C.m.vec.k <- array(,parm$clust$G)
    for (gg in 1:parm$clust$G) {
      parm$clust$C.m.vec.k[gg] <- sum(subset.c == gg)
    }

    parm$clust$C.m0.k <- sum(subset.c == 0)

    parm$clust$C.m.vec.k.comp <- parm$clust$C.m.vec - parm$clust$C.m.vec.k
    parm$clust$C.m0.k.comp <- parm$clust$C.m0 - parm$clust$C.m0.k

    u.v = runif(n=length(parm$col.subset.I))
    tmp.mt = t(parm$clust$cumSum_col_subset_post.prob.mt) < u.v
    subset.c <- parm$clust$c.v[parm$col.subset.I] <- apply(tmp.mt,1,sum) + 1

    parm$clust$C.m.vec.k <- array(,parm$clust$G)
    for (gg in 1:parm$clust$G) {
      parm$clust$C.m.vec.k[gg] <- sum(subset.c==gg)
    }
    parm$clust$C.m0.k <- sum(subset.c==0)

    parm$clust$C.m.vec = parm$clust$C.m.vec.k.comp + parm$clust$C.m.vec.k
    parm$clust$C.m0 = parm$clust$C.m0.k.comp + parm$clust$C.m0.k

    if (sum(subset.c != old.subset.c) > 0)
    { 
      union.subset.c = c(subset.c, old.subset.c)
      changed.union.subset.c = union.subset.c[subset.c!= old.subset.c]
      parm = fn.ClustList(parm, gg.set=unique(changed.union.subset.c))
      }

    err <- sRPM_fn.compact.consistency.check(parm)
    if (err > 0)
    {stop(paste("POST-UPDATE: failed consistency check: err=",err))
    }

  parm
}




fast_sRPM_fn.main <- function(parm, data.in)
{


  parm <- sRPM_fn.post.prob(parm)

	err <- sRPM_fn.consistency.check(parm)
	if (err > 0)
			{stop(paste("LOOP: failed consistency check: err=",err))
	}

 	err <- sRPM_fn.compact.consistency.check(parm)
	if (err > 0)
		{stop(paste("MAIN FUNCTION END: failed consistency check: err=",err))
		}

	parm
	}



