



fn.standarizeData <- function(full.data)
{
  for (xx in 1:full.data$d)
    {full.data$X[xx,] = (full.data$X[xx,] - mean(full.data$X[xx,]))/sd(full.data$X[xx,])
    }
  for (yy in 1:full.data$r)
  {full.data$Y.v = (full.data$Y.v - mean(full.data$Y.v))/sd(full.data$Y.v)
  }
  
  full.data
}
  
  
fn.foldedX <- function(n, p, p_t.v)
{
  X = array(,c(n,p))
  
  for (j in 1:p)
  {

    
    t = array(,n)
    
    rem = j - 1
    
    for (tt in n:2)
    {t[tt] = rem %/% prod(p_t.v[1:(tt-1)]) + 1
    rem = rem %% prod(p_t.v[1:(tt-1)])
    }
    
    t[1] = rem + 1
   
    X[,j] = t
  }
  
  X
  
}
  
  
fn.findNeighbors <- function(full.data)
{
  
  
  full.data$j.mt = array(,full.data$p_t.v)
  for (j in 1:full.data$p)
    {full.data$j.mt[full.data$X[1,j],full.data$X[2,j]]=j
    }
    
  full.data$neighbor.list = rep(list(NA), full.data$p)
  
  for (j in 1:full.data$p)
  {
    x.j = full.data$X[1,j]
    y.j = full.data$X[2,j]
    
    xNeigh = c(x.j-1, x.j, x.j+1)
    xNeigh = xNeigh[(xNeigh >=1) & (xNeigh <= full.data$p_t.v[1])]
    yNeigh = c(y.j-1, y.j, y.j+1)
    yNeigh = yNeigh[(yNeigh >=1) & (yNeigh <= full.data$p_t.v[2])]
    
    tmp = NULL
    
    for (i1 in xNeigh)
      for (i2 in yNeigh)
      {if ((i1 != x.j) | (i2 != y.j)) 
        {tmp = rbind(tmp, c(i1,i2))
        }
      }
    
    tmp2 = NULL
    
    for (tt in 1:nrow(tmp))
      {tmp2 = c(tmp2, full.data$j.mt[tmp[tt,1],tmp[tt,2]])
      }
    
    full.data$neighbor.list[[j]] = tmp2
  }
  
  full.data
}


fn.potts <- function(true_parm, full.data)
{
  indx = full.data$changedIndx
  if (is.null(indx))
  {
    indx = 1:full.data$p
  }
  
  for (j in indx)
  {c_neigh = true_parm$clust$c.v[full.data$neighbor.list[[j]]]
  
  log.prob_j = array(0,true_parm$clust$G)
  
   for (gg in unique(c_neigh)) 
     {
     for (ccc in unique(c_neigh))
       {log.prob_j[gg] =  log.prob_j[gg]+true_parm$clust$Upsilon[gg,ccc]*sum(gg==c_neigh[c_neigh==ccc])
        }
     }
  
  log.prob_j = log.prob_j - max(log.prob_j)
  
  
  true_parm$clust$c.v[j] = sample(1:true_parm$clust$G, size=1, prob=exp(log.prob_j ))
  }
  
  true_parm
}
  



genData <- function(d, p, p_t.v, scaleTheta, pottsIter, RSq=.99) {
  
  full.data <- NULL
  full.data$d = d
  full.data$p_t.v = p_t.v
  full.data$centroid = p_t.v/2
  # length of intensity vector
  full.data$r = 1
  
  full.data$p = p
  
  # generate unstandardized X
  full.data$X = fn.foldedX(d, p, p_t.v)
  
  
  full.data = fn.findNeighbors(full.data)
  
  true_parm <- NULL

  true_parm$b1 <- 5
  
  true_parm$p = p
  
  true_parm$scaleTheta = scaleTheta
  
  true_parm$clust <- NULL
 
  true_parm$clust$K = d
 
  true_parm$clust$G <- round(true_parm$b1*log(p))
  
  full.data$G.max = 10+true_parm$clust$G
  
  full.data$K.max = full.data$d
  
  true_parm$clust$phi.mt = array(,c(true_parm$clust$K,true_parm$clust$G))
  distSq.mt = array(0,c(true_parm$clust$G,true_parm$clust$G))
  
  for (t in 1:true_parm$clust$K)
  {true_parm$clust$phi.mt[t,] = runif(n=true_parm$clust$G, min=1,max=p_t.v[t])
  distSq.mt = distSq.mt + outer(true_parm$clust$phi.mt[t,],true_parm$clust$phi.mt[t,],"-")^2
  }
  
  true_parm$shrink.v = shrink.v = runif(n=true_parm$clust$G, min=.5)
  distSq.mt = diag(shrink.v) %*% distSq.mt %*% diag(shrink.v)
  
  # standardize distances to [0,1]
  true_parm$distSq.mt = distSq.mt/max(as.vector(distSq.mt))
  
  options(warn=0)
  tmp2 <- kmeans(t(full.data$X), iter.max=1000, centers=t(true_parm$clust$phi.mt), nstart=2, algorithm = "Lloyd")
  options(warn=2)
  #
  true_parm$clust$c.v <- tmp2$cluster  
  true_parm$clust$G <- length(tmp2$size)
  true_parm$clust$C.m.vec = as.vector(summary(as.factor(tmp2$cluster)))
  
  true_parm$clust$Upsilon = scaleTheta*(1-true_parm$distSq.mt)

  
  for (cc in 1:pottsIter)
  {true_parm = fn.potts(true_parm, full.data)
  print(paste("Potts, reps=",cc))
  }
  
  true_parm$clust$C.m.vec = as.vector(summary(as.factor(true_parm$clust$c.v)))
  
  true_parm$clust$mu2 = 0
  true_parm$clust$tau2 = 1
  true_parm$RSq = RSq
  true_parm$sigma = true_parm$clust$tau2*sqrt(1/RSq-1)

  true_parm$clust$v.v = rnorm(n=true_parm$clust$G, true_parm$clust$mu2, true_parm$clust$tau2)

  full.data$Y.v = true_parm$clust$v.v[true_parm$clust$c.v] + rnorm(n=p,sd=true_parm$sigma)
  
  full.data = fn.standarizeData(full.data)
  
  full.data$Y = array(full.data$Y.v, p_t.v)
  
  true_parm$clust$v = array(true_parm$clust$v.v[true_parm$clust$c.v], p_t.v)
  

  list (true_parm, full.data)
}


#' @keywords internal
genMoreData1 <- function(true_parm, full.data) {
  
  full.data2 <- full.data
  true_parm2 = true_parm

  full.data2$Y.v = true_parm2$clust$v.v[true_parm2$clust$c.v] + rnorm(n=p,sd=true_parm2$sigma)

  full.data2 = fn.standarizeData(full.data2)

  full.data2$Y = array(full.data2$Y.v, full.data2$p_t.v)
  
  true_parm2$clust$v = array(true_parm2$clust$v.v[true_parm2$clust$c.v], full.data2$p_t.v)

  
  list (true_parm2, full.data2)
}



genMoreData2 <- function(true_parm, full.data, pottsIter) {
  
  full.data2 <- full.data
  
  full.data2$X = fn.foldedX(full.data2$d, full.data2$p, full.data2$p_t.v)
  true_parm2 = true_parm
  
  
  full.data2 = fn.findNeighbors(full.data2)

  distSq.mt = array(0,c(true_parm$clust$G,true_parm$clust$G))
  
  indx = 1:true_parm2$clust$G 
  
  for (t in 1:true_parm$clust$K)
  {jiggleMax = full.data2$p_t.v[t]/2
  jiggle.v = runif(n=length(indx), min=-jiggleMax/2,max=jiggleMax/2)
  true_parm2$clust$phi.mt[t,indx] = true_parm$clust$phi.mt[t,indx] + jiggle.v
  distSq.mt = distSq.mt + outer(true_parm2$clust$phi.mt[t,],true_parm2$clust$phi.mt[t,],"-")^2
  }
  
  true_parm2$shrink.v = true_parm2$shrink.v*runif(n=true_parm2$clust$G,min=.1,max=1.9)
  true_parm2$shrink.v = sapply(true_parm2$shrink.v, min, 1)
  true_parm2$distSq.mt = diag(true_parm2$shrink.v) %*% distSq.mt %*% diag(true_parm2$shrink.v)
  
  true_parm2$distSq.mt = distSq.mt/max(as.vector(distSq.mt))

  rho = 0.9
  full.data2$changedIndx = sort(sample(1:full.data2$p,size=round(rho*full.data2$p)))
  

  options(warn=0)
  tmp2 <- kmeans(t(full.data2$X[,full.data2$changedIndx]), iter.max=1000, centers=t(true_parm2$clust$phi.mt), nstart=2, algorithm = "Lloyd")
  options(warn=2)
  #
  true_parm2$clust$c.v[full.data2$changedIndx] <- tmp2$cluster  
  true_parm2$clust$C.m.vec = as.vector(summary(as.factor(true_parm2$clust$c.v)))
  
  true_parm2$clust$Upsilon = true_parm2$scaleTheta*(1-true_parm2$distSq.mt)
  
  for (cc in 1:pottsIter)
  {true_parm2 = fn.potts(true_parm2, full.data2)
  print(paste("more data Potts, reps=",cc))
  }
  
  true_parm2$clust$C.m.vec = as.vector(summary(as.factor(true_parm2$clust$c.v)))
  
  full.data2$Y.v = true_parm2$clust$v.v[true_parm2$clust$c.v] + rnorm(n=p,sd=true_parm2$sigma)
 
  full.data2 = fn.standarizeData(full.data2)
    
  
  full.data2$Y = array(full.data2$Y.v, full.data2$p_t.v)
  
  true_parm2$clust$v = array(true_parm2$clust$v.v[true_parm2$clust$c.v], full.data2$p_t.v)
  
 
  list (true_parm2, full.data2)
}

