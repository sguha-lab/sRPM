
rm(list=ls())

indep.reps = 500
#########################

options(warn=0)

library(MASS)

options(error=recover)
options(warn=2)


load(file=paste("RData/tt_",1,".Rdata",sep=""))
num.psi = ncol(psiQuantile.mt)

# 1 -- replicate; 2 -- hypothesis (same/diff); 3 -- truth (similar/diff)
psiQuantile.ar = array(,c(indep.reps,2,num.psi))
v1 = paste("rep",1:indep.reps,sep="")
v2 = c("ReallySimilar","ReallyDiff")
v3 = NULL

dimnames(psiQuantile.ar) = list(v1,v2,v3)

##################

sens_tt.mt = spec_tt.mt = array(0, c(indep.reps, length(sens_tt.v)))
  
for (tt in 1:indep.reps)
    
  {
  load(file=paste("RData/tt_",tt,".Rdata",sep=""))
  
  psiQuantile.ar[tt,,] = psiQuantile.mt
  
  sens_tt.mt[tt,] = sens_tt.v
  spec_tt.mt[tt,] = spec_tt.v
  
  } # FOR loop

sens2.v = apply(sens_tt.mt, 2, mean, na.rm=TRUE)
spec2.v = apply(spec_tt.mt, 2, mean, na.rm=TRUE)


##################################
source("collated_calculations.R")

save.image(file="summary.Rdata")


