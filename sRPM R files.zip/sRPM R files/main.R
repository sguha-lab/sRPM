
rm(list=ls())

options(error=recover)

# get  array id value from environment variable passed by Linux
tt <- as.numeric(Sys.getenv('SLURM_ARRAY_TASK_ID'))
set.seed(100+tt)


require(MASS)
require(expm)
require(abind)
require(zeallot)
require(nicheROVER)

source("sourceAll.R")
path = getwd()
sourceDir(path, except=c("main.R","collated_main.R","collated_calculations.R"))

mcmc.run=1000

num.psi = 200

# 1 -- truth (identical/similar/diff); 2 -- quantiles of psi
psiQuantile.mt = array(,c(2,num.psi))
v1 = c("ReallySimilar","ReallyDiff")
dimnames(psiQuantile.mt) = list(v1,NULL)

sens_tt.v = spec_tt.v = array(,num.psi)

d=2
p_t.v = c(100,100) 
p = prod(p_t.v)
scaleTheta = 1.2

pottsIter = 200/20

n.burn1 = n.reps1 = n.burn2 = n.reps2 = mcmc.run

tmp <- genData(d, p, p_t.v, scaleTheta, pottsIter)
true_parm = tmp[[1]]
data = tmp[[2]]


print("@@@@@@@@@@@@@@")
print(paste("START:: tt=",tt))
print("@@@@@@@@@@@@@@")

All.Stuff.0 <- fn.mcmc(data, n.burn1, n.reps1, scaleTheta.in=1/100, updateClusterAlloc=TRUE, fixedClust=NULL, useLastImage=FALSE, init.All.Stuff=NULL)
    
fixedClust = fn.fixedClust(All.Stuff.0)
All.Stuff.0$fixedClust = fixedClust


All.Stuff.1 <- fn.mcmc(data, n.burn1/2, n.reps1/2, scaleTheta.in=mean(All.Stuff.0$scaleTheta.v), updateClusterAlloc=FALSE, fixedClust, useLastImage=FALSE, init.All.Stuff=NULL)

est.parm = fn.MLEClusters(All.Stuff.1, fixedClust, data)


for (trueProcess in 1:2)
{

  if (trueProcess == 1)
    {diffTrueProcess = FALSE
    txtTrueProcess = "similar images"
    tmp <- genMoreData1(true_parm, data)
    }
  if (trueProcess == 2)
    {diffTrueProcess = TRUE
    txtTrueProcess = "different images"
    tmp <- genMoreData2(true_parm, data, pottsIter)
    }
  
  true_parm2 = tmp[[1]]
  data2 = tmp[[2]]

 
  print("@@@@@@@@@@@@@@")
  print(paste("START:: tt=",tt, txtTrueProcess))
  print("@@@@@@@@@@@@@@")
  
  set.seed(1001*tt + 10000*trueProcess + 25)
  
  
  useLastImage = TRUE
    
   
  init.All.Stuff=All.Stuff.1
    fixedClust = All.Stuff.0$fixedClust
    scaleTheta.in=mean(All.Stuff.0$scaleTheta.v) 
    txtEstProcess = "_AssumeSame_"
    
  
  All.Stuff.2 <- fn.mcmc(data.in=data2, n.burn=n.burn2, n.reps=n.reps2, scaleTheta.in, updateClusterAlloc=TRUE, fixedClust, useLastImage, init.All.Stuff, num.psi, est.parm)
  
  if (!diffTrueProcess)
    {spec_tt.v=All.Stuff.2$spec.v
    }
  if (diffTrueProcess)
    {sens_tt.v=All.Stuff.2$sens.v
    }
  
  runningFixedTheta=mean(c(All.Stuff.0$scaleTheta.v,All.Stuff.2$scaleTheta.v))
    
  
  fixedClust2 = fn.fixedClust(All.Stuff.2)
  All.Stuff.2$fixedClust = fixedClust2
  
  psiQuantile.mt[trueProcess,] = All.Stuff.2$psiQuantiles
  
  print("@@@@@@@@@@@@@@")
  print(paste("END:: tt=",tt,txtTrueProcess))
  print("@@@@@@@@@@@@@@")
  

} # for (trueProcess in 1:2)


objects.v = ls()
objects.v = setdiff(objects.v, c("tt", "psiQuantile.mt", "num.psi", "sens_tt.v", "spec_tt.v"))

rm(list=objects.v)

save.image(file=paste("tt_",tt,".Rdata",sep=""))


  